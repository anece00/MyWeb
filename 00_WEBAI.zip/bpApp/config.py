# /config.py
db={
    'user': 'root',
    'password':'root',
    'host': 'localhost',
    'port': 3308,
    'database': 'db_ai'
}


# SQLALCHEMY DB 관련 설정 -------------------------------------------------------------------
import os

BASE_DIR = os.path.dirname(__file__)
DB_NAME = 'bpApp.db'
DB_NAME2 = 'db_test'

DB_SQLITE_URI = f'sqlite:///{os.path.join(BASE_DIR, DB_NAME)}'
DB_MYSQL_URI = f'mysql+pymysql://root:root@localhost:3306/{DB_NAME}'
DB_MARIA_URI = f'mariadb+mariadbconnector://root:root!@127.0.0.1:3308/{DB_NAME2}?charset=utf8mb4'

# 사용할 DBMS 설정 
SQLALCHEMY_DATABASE_URI = DB_MARIA_URI
SQLALCHEMY_TRACK_MODIFICATIONS = False

# DB_NAME = 'db_ai'

# db_url = f"mysql+mysqlconnector://{db['user']}:{db['password']}@" \
#          f"{db['host']}:{db['port']}/{db['database']}?charset=utf8mb4"
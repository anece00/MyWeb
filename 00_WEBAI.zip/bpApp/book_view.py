# ---------------------------------------------
# book기능 App ==>  Blueprint 인스턴스 생성
# --------------------------------------------- 
# 모듈 로딩 ------------------------------------
from flask import Blueprint, render_template

# Blueprint 인스턴스 생성 ------------------------
# URL => http://127.0.0.1:5000/book
blue_book = Blueprint('book', 
                      __name__, 
                      url_prefix='/book',
                      template_folder='templates')
# 클라이언트 요청 처리 라우팅 -----------------------
# URL => http://127.0.0.1:5000/book/
@blue_book.route('/')
def book_home():
    # templates/book/아래에 있는 index.html
    return render_template('book/index.html')

# URL => http://127.0.0.1:5000/book/read/<book_name>
@blue_book.route('/read/')
@blue_book.route('/read/<book_name>')
def read(book_name='Nothing'): 
    return f"I read a book called '{book_name}'."

# URL => http://127.0.0.1:5000/book/write
@blue_book.route('/write')
def write(): 
    return "Good Write Book !!!"
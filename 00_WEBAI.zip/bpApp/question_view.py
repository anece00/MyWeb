# ---------------------------------------------
# book기능 App ==>  Blueprint 인스턴스 생성
# --------------------------------------------- 
# 모듈 로딩 ------------------------------------
from flask import Blueprint, render_template, request,redirect, url_for
from .models import Question
from datetime import datetime
from bpApp.app import db

# Blueprint 인스턴스 생성 ------------------------
# URL => http://127.0.0.1:5000/book
blue_question = Blueprint('question', 
                      __name__, 
                      url_prefix='/question',
                      template_folder='templates')

# 클라이언트 요청 처리 라우팅 -----------------------
# URL => http://127.0.0.1:5000/question/list
@blue_question.route('/list')
def question_list():
    questions = Question.query.order_by(Question.create_date.desc())
    print(questions)
    return render_template('question/question_list.html', question_list=questions)


# URL => http://127.0.0.1:5000/question/create
@blue_question.route('/create')
def question_create():
    return render_template('question/question_create.html')

# URL => http://127.0.0.1:5000/question/insert
@blue_question.route('/insert', methods=['POST'])
def insert():
    subject_=request.form['subject']
    content_ = request.form['content']
    question_ = Question(subject=subject_, content=content_, create_date=datetime.now())
    db.session.add(question_)
    db.session.commit()
    print(f"url_for('question.question_list') ==> {url_for('question.question_list')}")
    print( "INSERT OK" )
    return redirect(url_for('question.question_list'))
from flask import Blueprint, render_template

blue_city = Blueprint('city', 
                      __name__, 
                      url_prefix='/city', 
                      template_folder='templates')

@blue_city.route('/')
def city_home():
    print('city_home')
    return render_template('city/index.html')

@blue_city.route('/seoul')
def seoul(): 
    return "서울 서울"

@blue_city.route('/daegu')
def daegu(): 
    return "대구 대구"
import lilypond
from PIL import Image


Image.open(lilypond.executable('simple.ly'))
# ----------------------------------------------------
# MVT Model 중 View : 클라이언트 요청 처리 즉, 라우팅
# ---------------------------------------------------- 
from flask import Blueprint, render_template

dbApp = Blueprint('dbApp', __name__,
                  url_prefix='/dbApp',
                  template_folder='templates',
                  static_folder='static')

# 클라이언트 요청 처리 라우팅 -----------------------
# URL => http://127.0.0.1:5000/dbApp
@dbApp.route('/')
def db_home():
    return render_template('dbApp/index.html')

from flask import Flask
from apps.dbApp import view
# from pathlib import Path                # 패스관련 모듈
# from flask_migrate import Migrate
# from flask_sqlalchemy import SQLAlchemy  
from sqlalchemy import create_engine, text
# from sqlalchemy.ext.declarative import declarative_base

# 전역변수 ---------------------------------------


# 사용자정의 함수 ---------------------------------
def create_app():
    app=Flask(__name__)
    
    app.register_blueprint(view.dbApp)
    
    
    app.config.from_pyfile("config.py")
    
    print(app.config['SQLALCHEMY_DATABASE_URI'])
    
    # Engine 객체 반환, 이 객체를 사용해 연결된 DB에 SQL를 실행
    dbEngine = create_engine(app.config['SQLALCHEMY_DATABASE_URI'])
    #database = create_engine(app.config['db_url'], encoding='utf-8', max_overflow=0)
    app.database = dbEngine

    
    # global db
    # db.init_app(app)
    # print(f'_db {db}')
    
    return app
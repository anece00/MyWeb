from flask import Flask

from apps.dbApp import db_view
from apps.minimalApp import minimal_view

# 전역변수 ---------------------------------------


# 사용자정의 함수 ---------------------------------
def create_app():
    app=Flask(__name__)
    
    # 설정 로딩
    app.config.from_pyfile("config.py")
    
    # 모듈별 객체 등록
    app.register_blueprint(db_view.dbApp)
    app.register_blueprint(minimal_view.minimalApp)

    return app
# 모듈 로딩 ----------------------------------
from flask import Flask, render_template, url_for
from flask import request

# Flask 객체 생성 => Web Server 기능의 객체 생성
app2 = Flask(__name__)

# 브라우저의 URI 입력된 부분에 따라서 보여줄 화면
# 내용 생성하기
@app2.route("/")        # http://127.0.0.1:5000/
def hello_world():
    return "<h1>==> FLASK~^^GOOD LUCK</h1>"

@app2.route("/good")    # http://127.0.0.1:5000/good
def good():
    return "/good => GOOD"

@app2.route("/happy")    # http://127.0.0.1:5000/happy
def contol():
    return "/happ => HAppy Ahppy"

# URI에서 입력된 데이터 변수에 담아서 사용 --------------
# "/<변수명>"
@app2.route("/happ/<name_>")
def getName(name_):
    return f'나의 이름은 {name_}'

# Template 적용하여 생성된 HTML 반환 -------------------
@app2.route("/test/<name_>")
@app2.route("/test/", endpoint="TTT")
def myHtml(name_=None):
    print(f"myHtml()  name_ : {name_}")
    # HTML에서의 변수명 키 = URI에서의 변수명 값
    # name=name_
    return render_template("index.html", name=name_)


@app2.route('/ping', methods=["POST"])
def ping(): 
	return 'pong'

# @app2.get("/test1")
# @app2.post("/test1")
# def test():
#     temp = request.args.get('name', "user01")
#     temp1 = request.args.get('juso', "평택시")
 
#     return "TEST " + temp + "-" + temp1

# if __name__ == '__main__':
#     app2.run(debug=True, port=3002)

# 모듈 로딩 ----------------------------------------
from flask import Flask, url_for, redirect, request, current_app
from flask import render_template, flash

# 전역변수 -----------------------------------------
DEBUG = True

g_User = None
g_Pass = None

# 사용자 함수 ---------------------------------------
def checkValid(data, kind, mLength=None):
    # data: 입력받은 데이터 kind : id, email, text 
    
    # 입력된 데이터 여부 체크
    if not data: 
        return False
    else:
         # 데이터의 규칙이 맞는지 체크
         if kind=='text':  return False if len(data) > mLength else True
    

# Flask Web Server 인스턴스 생성 --------------------
app=Flask(__name__)

#if DEBUG: print(f'현재 인스턴스 데이터 정보 : {app.cu}')
# SECRET_KEY를 추가한다
app.config["SECRET_KEY"] = "2AZSMss3p5QPbcY2hBsJ"


# Clienct 요청 처리 라우팅 --------------------------
@app.route('/login')
def login():
    g_User = request.form['userid']
    g_Pass = request.form['pass']
    return render_template('index.html')

# http://127.0.0.1:5000/, http://127.0.0.1:5000/index
@app.route('/')
@app.route('/index')
def home():
    return render_template('index.html')

# http://127.0.0.1:5000/conatct'
@app.route('/conatct')
def reg_contact():
    if DEBUG: print('reg_contact()')
    return render_template('contact.html', m='POST')

# http://127.0.0.1:5000/conatct/get'
@app.route('/conatct/get')
def reg_get():
    if DEBUG: print('reg_get()')
    return render_template('contact.html', m='GET')

# http://127.0.0.1:5000/conatct/complete
@app.route('/conatct/complete', methods=['POST', 'GET'], endpoint='contact_complete')
def complete_contact():
    # 입력 데이터 유효성 체크 변수
    isValid =True
    
    # POST 방식인 경우 처리
    if request.method == 'POST':
        uname=request.form["username"]
        #checkValid(uname, 'id', 8)
        if not uname : 
            isValid = False
            flash("이름은 필수입력입니다.", 'warning')
        
        uemail=request.form['email']
        if not uemail : 
            isValid = False
            flash("메일은 필수입력입니다.", 'warning')
            
        uDescribe=request.form['describe']
        if not uDescribe : 
            isValid = False
            flash("문의내용은 필수입력입니다.", 'warning')
        
        if isValid: return render_template('contact_complete.html') #return f'By POST => usernme :{uname}, email : {uemail}'
        else: return render_template('contact.html')
        
    # GET  방식인 경우 처리 
    else:
        uname=request.args.get("username")
        uemail=request.args.get("email")
        print(f'By GET => usernme :{uname} email : {uemail}')
        return f'By GET => usernme :{uname}, email : {uemail}'
        #return render_template('contact_complete.html')
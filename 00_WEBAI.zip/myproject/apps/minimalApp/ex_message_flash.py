# --------------------------------------------------------------
# 메시지 출력 
# --------------------------------------------------------------
#  모듈 로딩 ----------------------------------------------------
from flask import Flask, flash, redirect, render_template, request, url_for

# Flask Web Server 객체 생성
app = Flask(__name__)

# flash()함수에서 필수로 요청하는 값 
#app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'


# 클라이언트 요청 URL 처리 라우팅 -----------------------
# URL => http://127.0.0.1:5000/ 처리
@app.route('/')
def index():
    return render_template('index_2.html')

# URL => http://127.0.0.1:5000/login  처리
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'secret':
            error = 'Invalid credentials'
        else:
            flash('You were successfully logged in')
            return redirect(url_for('index'))
    return render_template('login.html', error=error)
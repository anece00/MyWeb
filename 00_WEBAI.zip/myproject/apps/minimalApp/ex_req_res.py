# ------------------------------------------
# Request & Response
# ------------------------------------------
# 모듈로딩 ----------------------------------
from flask import Flask, request
from flask import make_response, render_template

# 전역변수 ----------------------------------
DEBUG = True

# Flask Web Server 인스턴스 생성 ------------
app = Flask(__name__)


# Clinet 요청에 대한 처리 라우팅 -------------
@app.route('/')
def index():
    # 클라이언트 요청 메시지 확인
    if DEBUG: print(f'request ====>\n{request}')
    if DEBUG: print(f'request [headers]====>\n{request.headers}')
    if DEBUG: print(f'request ====>\n{request.data}')
    
    
    # 클라이언트 요청에 대한 응답 메시지 생성
    res=make_response(render_template('index.html'))
    
    # 쿠키 생성
    res.set_cookie("test", "abc123")
    
    if DEBUG: print(f'res====>\n{res}')
    if DEBUG: print(f'res [response] ====>\n{res.response}')
    if DEBUG: print(f'res [headers] ====>\n{res.headers}')
    return res


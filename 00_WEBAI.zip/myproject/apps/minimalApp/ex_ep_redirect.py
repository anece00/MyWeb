# 모듈로딩 ----------------------------------------
from flask import Flask,request,url_for,redirect

# Flask Web Server 인스턴스 생성 ------------------
app = Flask(__name__)

@app.route("/index")
def index():
	return "/index"

@app.route("/index2/<data>", endpoint="indexData")
def index2(data):
	return f"/index2/{data}"

#view1 = board1/<data>
@app.route("/board1/<data>", endpoint="view1")
def board1(data):
	return url_for("view1", data=data)
	
@app.route("/board2/<data>", endpoint="view2")
def board2(data):
	return url_for("view2", data=data)

#indexData = index/<data> , index/data = url
@app.route("/board3/<data>")
def board3(data):
	print (url_for("indexData",data=data))
	return redirect(url_for("indexData",data=data))
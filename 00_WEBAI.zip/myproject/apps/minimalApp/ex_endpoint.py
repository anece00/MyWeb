# 모듈 로딩 -------------------------------------
from flask import Flask, render_template, url_for


# Flask Web Server 인스턴스 생성 ----------------
app=Flask(__name__)

# Flask Web Server가 Client요청 URL처리 부분 ----
# @app.route('/')
# def index():
#     return 'route("/")'

# http://127.0.0.1:8000/hello/홍길동
@app.route('/hello/<name>', endpoint="SHOW NAME")
def hello(name):
    return f"Your name is {name}!!"

# URL 테스트 -------------------------------------------
# with app.test_request_context():
#     print("index's URL : ", url_for('index'))
#     print("hello's URL : ", url_for('SHOW NAME', name='TOM'))

# ------------------------------------------------------

app.add_url_rule("/", endpoint='index')

@app.endpoint("index")
def index():
    print('Dsssss -> index()')
    return render_template('index.html')

#app.add_url_rule("/", view_func=index)



# ----------------------------------------------------
# MVT Model 중 View : 클라이언트 요청 처리 즉, 라우팅
# ---------------------------------------------------- 
from flask import Blueprint, render_template

minimalApp = Blueprint('minimal', __name__,
                        url_prefix='/minimal',
                        template_folder='templates',
                        static_folder='static')

# 클라이언트 요청 처리 라우팅 -----------------------
# URL => http://127.0.0.1:5000/minimal
@minimalApp.route('/')
def minimal_home():
    return render_template('minimal/index.html')


# 브라우저의 URI 입력된 부분에 따라서 보여줄 화면
# 내용 생성하기
# http://127.0.0.1:5000/minimal
@minimalApp.route("/")        
def hello_world():
    return "<h1>==> FLASK~^^GOOD LUCK</h1>"

# http://127.0.0.1:5000/minimal/good
@minimalApp.route("/good")    
def good():
    return "/good => GOOD"

# http://127.0.0.1:5000/minimal/happy
@minimalApp.route("/happy")    
def contol():
    return "/happ => HAppy Ahppy"

# URI에서 입력된 데이터 변수에 담아서 사용 --------------
# http://127.0.0.1:5000/minimal/happy/<변수명>
@minimalApp.route("/happ/<name_>")
def getName(name_):
    return f'나의 이름은 {name_}'

# Template 적용하여 생성된 HTML 반환 -------------------
# http://127.0.0.1:5000/minimal/test/<name_>
# http://127.0.0.1:5000/minimal/test
@minimalApp.route("/test/<name_>")
@minimalApp.route("/test/", endpoint="TTT")
def myHtml(name_=None):
    print(f"myHtml()  name_ : {name_}")
    # HTML에서의 변수명 키 = URI에서의 변수명 값
    # name=name_
    return render_template("index.html", name=name_)



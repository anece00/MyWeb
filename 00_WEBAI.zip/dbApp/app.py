# -------------------------------------------------------------------------
import os
#from models import db
from flask import Flask, render_template
#from . import orm_models
import sqlalchemy
from sqlalchemy.orm import sessionmaker

# db_url = "mariadb+mariadbconnector://root:root!@127.0.0.1:3308/db_orm" 
# engine = sqlalchemy.create_engine(db_url)  #'sqlite:///C:\\dev\\db\\orm.db')
# Session = sessionmaker(bind=engine)

# DB table 생성
#orm_models.create_tb(engine)

app = Flask(__name__)

# 라우팅 ------------------------------------------------
@app.route('/register')
def register():
    return render_template('register.html')

@app.route('/')
def hello_world():
    return render_template('db.html')
# 라우팅 ------------------------------------------------

# DB관련
# basdir = os.path.abspath(os.path.dirname(__file__))
# dbfile = os.path.join(basdir, 'db.sqlite')

# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + dbfile
# app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# app.config['SECRET_KEY'] = 'jqiowejrojzxcovnklqnweiorjqwoijroi'

# db.init_app(app)
# db.app = app
# db.create_all()



'''
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URL'] =  "mariadb+mariadbconnector://root:root!@127.0.0.1:3308/db_test" #'sqlite:////tmp/test.db' # db 경로 설정
db = SQLAlchemy(app)

# Models => DB Table ==> Class User
class User(db.Model):
    
    __tablename__ = 'user'
    
    # db.Column() : 필드/컬럼의 데이터 타입 정보와 제약 조건
    id = db.Column(db.Integer, primary_key=True) 
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

'''

# -------------------------------------------------------------------------    

# from flask import Flask, render_template
# from flask_sqlalchemy import SQLAlchemy
# from .models import Members

# app = Flask(__name__)

# # database 설정파일
# app.config["SQLALCHEMY_DATABASE_URI"] = "mariadb+mariadbconnector://root:root!@127.0.0.1:3308/db_test"
# #app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:1234@localhost:3306/testdb"
# app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
# db = SQLAlchemy(app)

# @app.route('/home')
# def home():
#     return render_template('home.html')
    
# @app.route("/one")
# def home():
# 	member = Members.query.first()
# 	return 'Hello {0}, {1}, {2}, {3}, {4}'\
# 		.format(member.name, member.email, member.phone, member.start.isoformat(), member.end.isoformat())
# 	#return render_template('home.html')
    
# @app.route('/all')
# def select_all():
#     members = Members.query.all()
#     return render_template('db.html', members=members)
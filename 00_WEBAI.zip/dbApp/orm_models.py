# ------------------------------------------------------------
# Declarative : 데이터 모델 객체와 데이터베이스 테이블을 연결
# ------------------------------------------------------------
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String

Base = declarative_base()

class Students(Base):
    __tablename__ = 'students'
    
    num = Column(String(50), primary_key=True)
    name = Column(String(50))
    
    def __init__(self, num, name):
        self.num = num
        self.name = name
        
    def __repr__(self):
       return "<Students('%s', '%s')>" % (self.num, self.name)
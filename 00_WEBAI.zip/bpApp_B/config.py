# /config.py
db={
    'user': 'root',
    'password':'root',
    'host': 'localhost',
    'port': 3308,
    'database': 'db_ai'
}


# SQLALCHEMY DB 관련 설정 -------------------------------------------------------------------
import os
#SQLALCHEMY_DATABASE_URI ="mysql+pymysql://root:1234@localhost:3306/testdb"
#SQLALCHEMY_DATABASE_URI ="mariadb+mariadbconnector://root:root!@127.0.0.1:3308/db_ai"
BASE_DIR = os.path.dirname(__file__)
SQLALCHEMY_DATABASE_URI = 'sqlite:///{}'.format(os.path.join(BASE_DIR, 'myapp.db'))
SQLALCHEMY_TRACK_MODIFICATIONS = False

DB_NAME = 'db_ai'


db_url = f"mysql+mysqlconnector://{db['user']}:{db['password']}@" \
         f"{db['host']}:{db['port']}/{db['database']}?charset=utf8"
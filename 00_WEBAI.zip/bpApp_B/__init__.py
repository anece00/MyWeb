# 모듈 로딩 ----------------------------
from flask import Flask
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy



# 전역 변수 ----------------------------
db = SQLAlchemy()
migrate = Migrate()

# 애플리케이션 팩토리 함수 --------------
def create_app():
    # Flask Web Server App 생성
    app = Flask(__name__)
    
    # 설정 로딩
    app.config.from_pyfile("config.py")
    if app.debug : 
        print(f'SQLALCHEMY_DATABASE_URI : {app.config["SQLALCHEMY_DATABASE_URI"]}')
    
    # ORM 연동
    db.init_app(app)
    migrate.init_app(app, db)

    # circular import 
    from . import models
    
    # 기능단위 앱 Blueprint 객체 등록
    from . import book_view, city_view, question_views, answer_view
    app.register_blueprint(book_view.blue_book)
    app.register_blueprint(city_view.blue_city)
    app.register_blueprint(question_views.blue_question)
    app.register_blueprint(answer_view.blue_answer)
    

    return app

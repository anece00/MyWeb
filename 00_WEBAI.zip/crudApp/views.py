# --------------------------------------------------------
# MVT 모델 => View :  클라이언트 요청 받아 처리 즉, 라우팅
# --------------------------------------------------------
from flask import Blueprint, redirect, render_template, url_for
#from flask_login import login_required

#from apps.app import db
# from apps.crud.forms import UserForm
from apps.crudApp.models import Members

# Blueprint
crud_blue = Blueprint(
    "crud",
    __name__,
    url_prefix='/crud',
    template_folder="templates",
    static_folder="static",
)

# 클라이언트 요청 URL 처리 라우팅 -----------------------
@crud_blue.route('/')
def index():
    return render_template('crud/index.html')


@crud_blue.route("/one")
def home():
	member = Members.query.first()
	return 'Hello {0}, {1}, {2}, {3}, {4}'\
		.format(member.name, member.email, member.phone, member.start.isoformat(), member.end.isoformat())
	#return render_template('home.html')
    
@crud_blue.route('/all')
def select_all():
    members = Members.query.all()
    return render_template('db.html', members=members)

# index 엔드포인트를 작성하고 index.html을 반환한다
# @crud_blue.route("/")
# @login_required
# def index():
#     return render_template("crud/index.html")


# @crud_blue.route("/sql")
# @login_required
# def sql():
#     db.session.query(User).all()
#     return "콘솔 로그를 확인해 주세요"


# @crud_blue.route("/users/new", methods=["GET", "POST"])
# @login_required
# def create_user():
#     # UserForm을 인스턴스화한다
#     form = UserForm()

#     # 폼의 값을 벨리데이트한다
#     if form.validate_on_submit():
#         # 사용자를 작성한다
#         user = User(
#             username=form.username.data,
#             email=form.email.data,
#             password=form.password.data,
#         )

#         # 사용자를 추가하고 커밋한다
#         db.session.add(user)
#         db.session.commit()

#         # 사용자의 일람 화면으로 리다이렉트한다
#         return redirect(url_for("crud.users"))
#     return render_template("crud/create.html", form=form)


# @crud_blue.route("/users")
# @login_required
# def users():
#     """사용자의 일람을 취득한다"""
#     users = User.query.all()
#     return render_template("crud/index.html", users=users)


# # methods에 GET과 POST를 지정한다
# @crud_blue.route("/users/<user_id>", methods=["GET", "POST"])
# @login_required
# def edit_user(user_id):
#     form = UserForm()

#     # User 모델을 이용하여 사용자를 취득한다
#     user = User.query.filter_by(id=user_id).first()

#     # form으로부터 제출된 경우는 사용자를 갱신하여 사용자의 일람 화면으로 리다이렉트한다
#     if form.validate_on_submit():
#         user.username = form.username.data
#         user.email = form.email.data
#         user.password = form.password.data
#         db.session.add(user)
#         db.session.commit()
#         return redirect(url_for("crud.users"))

#     # GET의 경우는 HTML을 반환한다
#     return render_template("crud/edit.html", user=user, form=form)


# @crud_blue.route("/users/<user_id>/delete", methods=["POST"])
# @login_required
# def delete_user(user_id):
#     user = User.query.filter_by(id=user_id).first()
#     db.session.delete(user)
#     db.session.commit()
#     return redirect(url_for("crud.users"))

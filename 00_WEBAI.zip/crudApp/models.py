# ------------------------------------------
# DB의 Table을 클래스화
# ------------------------------------------
from apps.app import db 
from werkzeug.security import generate_password_hash
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

class Members(db.Model):
    """ table name : members
        table info 
    - id : index id 
    - name 
    - start: start datetime
    - end: end datetime """
    
    __tablename__ = 'members'
    
    id = db.Column(db.Integer, primary_key=True, nullable=False, autoincrement=True)
    name = db.Column(db.String(20, 'utf8mb4_unicode_ci'))
    email = db.Column(db.String(50, 'utf8mb4_unicode_ci'))
    phone = db.Column(db.String(20, 'utf8mb4_unicode_ci'))
    start = db.Column(db.DateTime, default=datetime.utcnow())
    end = db.Column(db.DateTime, default=datetime.utcnow())

    def __init__(self, name, email, phone, start, end):
        self.name = name
        self.email = email
        self.phone = phone
        self.start = start
        self.end = end


class User(db.Model):
    # 테이블명 설정
    __tablename__ = "users"
    
    # 컬럼 정의
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, index=True)
    email = db.Column(db.String, unique=True, index=True)
    password_hash = db.Column(db.String)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)


    # 비밀번호 관련 getter/settetr
    @property
    def password(self): raise AttributeError("읽어 들일 수 없음")

    @password.setter
    def password(self, password): self.password_hash = generate_password_hash(password)
